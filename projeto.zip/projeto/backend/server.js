const express = require("express");
const cors = require("cors");

const app = express();
const PORT = 3000;

app.use(cors());

const dados = [
  { id: 1, nome: "Letícia", curso: "ADS" },
  { id: 2, nome: "Mateus", curso: "Engenharia" },
  { id: 3, nome: "Amanda", curso: "Design" }
];

app.get("/api/alunos", (req, res) => {
  res.json(dados);
});

app.listen(PORT, () => {
  console.log(`Servidor rodando em http://localhost:${PORT}`);
});