fetch("http://localhost:3000/api/alunos")
  .then(response => response.json())
  .then(dados => {
    const lista = document.getElementById("lista-alunos");
    dados.forEach(aluno => {
      const li = document.createElement("li");
      li.textContent = `${aluno.nome} - ${aluno.curso}`;
      lista.appendChild(li);
    });
  })
  .catch(erro => console.error("Erro ao buscar dados:", erro));